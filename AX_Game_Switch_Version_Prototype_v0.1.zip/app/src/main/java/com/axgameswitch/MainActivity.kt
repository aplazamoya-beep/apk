package com.axgameswitch

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile

private val Ink = Color(0xFF101820)
private val Panel = Color(0xFF1D2A36)
private val Red = Color(0xFFE60023)
private val Muted = Color(0xFFB9C5D0)

data class GameEntry(val name: String, val uri: Uri, val size: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AXApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AXApp() {
    var selectedTab by remember { mutableStateOf(0) }
    var games by remember { mutableStateOf(listOf<GameEntry>()) }
    var profile by remember { mutableStateOf("Equilibrado") }
    var notice by remember { mutableStateOf<String?>(null) }
    val context = androidx.compose.ui.platform.LocalContext.current

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        val added = uris.mapNotNull { uri ->
            val doc = DocumentFile.fromSingleUri(context, uri)
            if (doc != null) {
                GameEntry(doc.name ?: "Archivo importado", uri, formatSize(doc.length()))
            } else null
        }
        games = (games + added).distinctBy { it.uri }
        if (added.isNotEmpty()) notice = "${added.size} archivo(s) añadidos a tu biblioteca."
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Red,
            background = Ink,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("AX GAME", fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                            Text("SWITCH VERSION  •  v0.1", fontSize = 10.sp, color = Muted)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.Gamepad, contentDescription = null) },
                        label = { Text("Biblioteca") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                        label = { Text("Ajustes") }
                    )
                }
            },
            floatingActionButton = {
                if (selectedTab == 0) {
                    ExtendedFloatingActionButton(
                        onClick = { picker.launch(arrayOf("*/*")) },
                        containerColor = Red,
                        contentColor = Color.White,
                        icon = { Icon(Icons.Default.Add, contentDescription = null) },
                        text = { Text("Importar juegos") }
                    )
                }
            },
            snackbarHost = {
                notice?.let { message ->
                    Snackbar(
                        action = { TextButton(onClick = { notice = null }) { Text("OK") } }
                    ) { Text(message) }
                }
            }
        ) { padding ->
            if (selectedTab == 0) {
                LibraryScreen(games, Modifier.padding(padding))
            } else {
                SettingsScreen(profile, { profile = it }, Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun LibraryScreen(games: List<GameEntry>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Tu biblioteca", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("Importa archivos de juegos que tengas derecho a utilizar.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SystemTile("Switch 1", "Biblioteca preparada", Modifier.weight(1f))
            SystemTile("Switch 2", "Integración futura", Modifier.weight(1f))
        }
        Spacer(Modifier.height(22.dp))
        Text("Juegos importados (${games.size})", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        if (games.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(
                    Modifier.fillMaxWidth().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null, tint = Muted, modifier = Modifier.size(38.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("Todavía no hay juegos", fontWeight = FontWeight.Bold)
                    Text("Usa “Importar juegos” para añadir tus archivos.", color = Muted, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(games) { game ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Gamepad, contentDescription = null, tint = Red, modifier = Modifier.size(30.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(game.name, fontWeight = FontWeight.SemiBold)
                                Text(game.size, color = Muted, fontSize = 11.sp)
                            }
                            Text("Importado", color = Muted, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Nota: esta versión organiza archivos; todavía no ejecuta juegos.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun SystemTile(title: String, subtitle: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun SettingsScreen(profile: String, onProfileChange: (String) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Rendimiento", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Selecciona un perfil inicial. Los perfiles no garantizan compatibilidad: el rendimiento depende del dispositivo y del motor.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        listOf("Ahorro (gama baja)", "Equilibrado", "Alto rendimiento (gama alta)").forEach { option ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                colors = CardDefaults.cardColors(containerColor = Panel),
                onClick = { onProfileChange(option) }
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = profile == option, onClick = { onProfileChange(option) })
                    Spacer(Modifier.width(8.dp))
                    Text(option)
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Motor de emulación", fontWeight = FontWeight.Bold)
        Text("Sin motor integrado en esta versión. La integración se evaluará por separado para cada sistema, respetando licencias y requisitos legales.", color = Muted, fontSize = 12.sp)
    }
}

private fun formatSize(bytes: Long): String {
    if (bytes <= 0) return "Tamaño no disponible"
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb < 1024) String.format("%.1f MB", mb)
    else String.format("%.2f GB", mb / 1024)
}
