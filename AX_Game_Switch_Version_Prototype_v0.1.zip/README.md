# AX Game Switch Version — v0.1

Prototipo Android nativo en Kotlin + Jetpack Compose.

## Incluye
- Pantalla principal AX GAME.
- Biblioteca local en memoria.
- Selector de archivos Android (SAF) para importar archivos elegidos por el usuario.
- Perfiles de rendimiento visuales: ahorro, equilibrado y alto rendimiento.
- Pantalla de estado de Switch 1 / Switch 2.

## Limitaciones de esta versión
- No contiene motores de emulación.
- No incluye juegos, firmware, BIOS ni claves.
- Importar un archivo no significa que sea compatible ni que pueda ejecutarse.
- La biblioteca todavía no persiste entre reinicios; Room se incorporará en la siguiente iteración.
- Switch 2 queda como objetivo de integración sujeto a disponibilidad técnica y licencias.

## Requisitos
- Android Studio Ladybug o posterior.
- JDK 17.
- Android SDK 35.

## Compilar APK
1. Abre esta carpeta desde Android Studio.
2. Espera la sincronización de Gradle.
3. Conecta un teléfono o inicia un emulador Android.
4. Ejecuta `app`.
5. Para generar APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

El APK de depuración aparecerá normalmente en `app/build/outputs/apk/debug/app-debug.apk`.

## Próximos pasos
1. Persistencia de biblioteca con Room.
2. Metadatos, carátulas y detección de duplicados.
3. Permisos persistentes SAF y validación de formatos.
4. Integración de un motor externo compatible y legal, evaluado por separado.
